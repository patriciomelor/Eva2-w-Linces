<div class="flex" >
    <br><br>
    <div class="row">
        <h1 class="text-center">MISIÓN Y VISIÓN</h1>
    </div>      
    <div class="img3">
        <img src=src/media/misionVision/imagenmision.jpg id="img1">
    </div>   
    <div class="flex-container text-center Fgris">
        <p class="padNos" style="padding-top:40px"><strong>Nuestra misión en Terrasol Parcelas es ofrecer a nuestros clientes oportunidades únicas para invertir en la naturaleza y la tranquilidad. Estamos muy comprometidos con un enfoque innovador y centrado en el cliente. Ofrecemos un estilo de vida totalmente rodeado de naturaleza y con las comodidades necesarias para vivir en armonía. </strong></p>
    </div>
    <div class="text-center">
        <div class="img3">
    <img src=src/media/misionVision/Imagenvision.jpg id=img1>
    </div class="flex-container text-center Fgris">
        <p class="padNos" style="padding-top:40px"> <strong>Nuestra visión es ser reconocidos como líderes en el mercado inmobiliario, destacándonos por nuestro compromiso con la accesibilidad financiera y la transparencia hacia cada uno de nuestros clientes. Nos interesa ser confiables y transparentes al entregar oportunidades realistas.
        </strong></p>
        <hr>
    </div>
</div>    
</section>
